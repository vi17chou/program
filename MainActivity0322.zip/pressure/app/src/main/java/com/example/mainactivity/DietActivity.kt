package com.example.mainactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DietActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diet)
    }
}